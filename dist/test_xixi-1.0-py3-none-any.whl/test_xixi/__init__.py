from test_xixi.main import xixi_class
__all__=['xixi_class']