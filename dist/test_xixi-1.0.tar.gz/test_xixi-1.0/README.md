# test_xixi软件说明
> 软件简介：
## 1.如何开始运行test_xixi

## 2.test_xixiの主要功能及介绍

## 3.test_xixiの目录结构

## 4.test_xixiの原理

这是一个测试包
用cmd进入到该包中，执行以下代码，会自动找到
python -m pip install --upgrade setuptools wheel
python setup.py sdist bdist_wheel

# include pyPacking_ran315/resouce/*.ini pyPacking_ran315/resouce/*.py
# recursive-include examples *.txt *.py
# prune examples/sample?/build