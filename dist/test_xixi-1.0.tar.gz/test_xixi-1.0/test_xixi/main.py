
class xixi_class:
    def xixi_func(self):
        print('嘻嘻嘻嘻')
